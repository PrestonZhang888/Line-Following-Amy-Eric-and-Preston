#include "RobotMotion.h"
#include "RobotConfig.h"
#include "RobotSensors.h"
#include <Zumo32U4.h>

Zumo32U4Motors   motors;
Zumo32U4Encoders encoders;

// ===== BASIC MOVEMENT =====

void driveDistance(float centimeters) {
    encoders.getCountsAndResetLeft();
    encoders.getCountsAndResetRight();
    int targetCounts = abs(centimeters) * COUNTS_PER_CM;
    int speed = (centimeters > 0) ? DRIVE_SPEED : -DRIVE_SPEED;
    motors.setSpeeds(speed, speed);
    while (abs(encoders.getCountsLeft()) < targetCounts) delay(10);
    motors.setSpeeds(0, 0);
}

void turnDegrees(float degrees) {
    encoders.getCountsAndResetLeft();
    encoders.getCountsAndResetRight();
    int targetCounts = abs(degrees) * COUNTS_PER_DEGREE;
    int leftSpeed  = (degrees > 0) ? TURN_SPEED : -TURN_SPEED;
    int rightSpeed = -leftSpeed;
    motors.setSpeeds(leftSpeed, rightSpeed);
    while (abs(encoders.getCountsLeft()) < targetCounts) delay(10);
    motors.setSpeeds(0, 0);
}

void turnLeft() {
    encoders.getCountsAndResetLeft();
    encoders.getCountsAndResetRight();
    motors.setSpeeds(-TURN_SPEED, TURN_SPEED);
    while (abs(encoders.getCountsLeft()) < COUNTS_PER_DEGREE * 85) delay(1);
    motors.setSpeeds(0, 0);
    delay(100);
    int attempts = 0;
    while (attempts < 50) {
        lineSensors.read(rawSensorValues);
        if (rawSensorValues[2] > 600) { motors.setSpeeds(0, 0); return; }
        motors.setSpeeds(-80, 80);
        delay(20);
        attempts++;
    }
    motors.setSpeeds(0, 0);
}

void turnRight() {
    encoders.getCountsAndResetLeft();
    encoders.getCountsAndResetRight();
    motors.setSpeeds(TURN_SPEED, -TURN_SPEED);
    while (abs(encoders.getCountsLeft()) < COUNTS_PER_DEGREE * 85) delay(1);
    motors.setSpeeds(0, 0);
    delay(100);
    int attempts = 0;
    while (attempts < 50) {
        lineSensors.read(rawSensorValues);
        if (rawSensorValues[2] > 600) { motors.setSpeeds(0, 0); return; }
        motors.setSpeeds(80, -80);
        delay(20);
        attempts++;
    }
    motors.setSpeeds(0, 0);
}

void turnAround() {
    encoders.getCountsAndResetLeft();
    encoders.getCountsAndResetRight();
    motors.setSpeeds(TURN_SPEED, -TURN_SPEED);
    while (abs(encoders.getCountsLeft()) < COUNTS_PER_DEGREE * 175) delay(1);
    motors.setSpeeds(0, 0);
    delay(100);
    int attempts = 0;
    while (attempts < 100) {
        lineSensors.read(rawSensorValues);
        if (rawSensorValues[2] > 600) { motors.setSpeeds(0, 0); return; }
        motors.setSpeeds(120, -120);
        delay(10);
        attempts++;
    }
    motors.setSpeeds(0, 0);
}

// ===== STAGED AVOIDANCE =====

static int           avoidStage = 0;
static unsigned long stageStart = 0;
static bool          goLeft     = false; // always false — always go right

void resetAvoidance() {
    motors.setSpeeds(0, 0);
    delay(200);
    goLeft = false;
    avoidStage = 0;
    stageStart = millis();
}

bool stepAvoidance() {
    unsigned long now     = millis();
    unsigned long elapsed = now - stageStart;

    // Helper values — flip motor directions based on goLeft
    // goLeft=false (go right): stage1 turns right, stage3 turns left, stage5 turns left
    // goLeft=true  (go left):  stage1 turns left,  stage3 turns right, stage5 turns right
    int turnFirstL  = goLeft ? -AVOID_SPEED :  AVOID_SPEED; // stage 1 left motor
    int turnFirstR  = goLeft ?  AVOID_SPEED : -AVOID_SPEED; // stage 1 right motor
    int turnParalL  = goLeft ?  AVOID_SPEED : -AVOID_SPEED; // stage 3 left motor
    int turnParalR  = goLeft ? -AVOID_SPEED :  AVOID_SPEED; // stage 3 right motor
    int turnBackL   = goLeft ?  AVOID_SPEED : -AVOID_SPEED; // stage 5 left motor
    int turnBackR   = goLeft ? -AVOID_SPEED :  AVOID_SPEED; // stage 5 right motor
    int sweepL      = goLeft ? -80 :  80;                   // stage 7 left motor
    int sweepR      = goLeft ?  80 : -80;                   // stage 7 right motor

    switch (avoidStage) {

        // --- Stage 0: brief stop ---
        case 0: {
            motors.setSpeeds(0, 0);
            if (elapsed >= 200) {
                avoidStage = 1;
                stageStart = now;
            }
            return false;
        }

        // --- Stage 1: turn away from obstacle (~90°) ---
        case 1: {
            motors.setSpeeds(turnFirstL, turnFirstR);
            if (elapsed >= AVOID_TURN_MS) {
                motors.setSpeeds(0, 0);
                delay(100);
                avoidStage = 2;
                stageStart = millis();
            }
            return false;
        }

        // --- Stage 2: drive forward alongside obstacle ---
        case 2: {
            motors.setSpeeds(AVOID_SPEED, AVOID_SPEED);
            lineSensors.read(rawSensorValues);
            for (int i = 0; i < 5; i++) {
                if (rawSensorValues[i] > 600) {
                    motors.setSpeeds(0, 0);
                    avoidStage = 0;
                    return true;
                }
            }
            if (elapsed >= AVOID_ALONGSIDE_MS) {
                motors.setSpeeds(0, 0);
                delay(100);
                avoidStage = 3;
                stageStart = millis();
            }
            return false;
        }

        // --- Stage 3: turn parallel to original path (~90°) ---
        case 3: {
            motors.setSpeeds(turnParalL, turnParalR);
            if (elapsed >= AVOID_TURN_MS) {
                motors.setSpeeds(0, 0);
                delay(100);
                avoidStage = 4;
                stageStart = millis();
            }
            return false;
        }

        // --- Stage 4: drive forward past obstacle ---
        case 4: {
            motors.setSpeeds(AVOID_SPEED, AVOID_SPEED);
            lineSensors.read(rawSensorValues);
            for (int i = 0; i < 5; i++) {
                if (rawSensorValues[i] > 600) {
                    motors.setSpeeds(0, 0);
                    avoidStage = 0;
                    return true;
                }
            }
            if (elapsed >= AVOID_FORWARD_MS) {
                motors.setSpeeds(0, 0);
                delay(100);
                avoidStage = 5;
                stageStart = millis();
            }
            return false;
        }

        // --- Stage 5: turn back toward line (~90°) ---
        case 5: {
            motors.setSpeeds(turnBackL, turnBackR);
            if (elapsed >= RETURN_TURN_MS) {
                motors.setSpeeds(0, 0);
                delay(100);
                avoidStage = 6;
                stageStart = millis();
            }
            return false;
        }

        // --- Stage 6: drive forward searching for line (3s timeout) ---
        case 6: {
            motors.setSpeeds(AVOID_SPEED, AVOID_SPEED);
            lineSensors.read(rawSensorValues);
            for (int i = 0; i < 5; i++) {
                if (rawSensorValues[i] > 600) {
                    motors.setSpeeds(0, 0);
                    avoidStage = 0;
                    return true;
                }
            }
            if (elapsed >= 3000) {
                motors.setSpeeds(0, 0);
                delay(100);
                avoidStage = 7;
                stageStart = millis();
            }
            return false;
        }

        // --- Stage 7: sweep toward line side (1.5s timeout) ---
        case 7: {
            motors.setSpeeds(sweepL, sweepR);
            lineSensors.read(rawSensorValues);
            for (int i = 0; i < 5; i++) {
                if (rawSensorValues[i] > 600) {
                    motors.setSpeeds(0, 0);
                    avoidStage = 0;
                    return true;
                }
            }
            if (elapsed >= 1500) {
                motors.setSpeeds(0, 0);
                avoidStage = 0;
            }
            return false;
        }

        default: {
            motors.setSpeeds(0, 0);
            avoidStage = 0;
            return false;
        }
    }

    return false;
}