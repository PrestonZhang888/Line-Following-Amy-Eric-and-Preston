#include <Zumo32U4.h>
#include "RobotConfig.h"
#include "RobotMotion.h"
#include "RobotSensors.h"
#include "RobotDisplay.h"

extern Zumo32U4Motors motors;
extern Zumo32U4ButtonA buttonA;
extern Zumo32U4OLED display;

Zumo32U4ButtonB buttonB;

RobotState currentState = STOPPED;
unsigned long lastLineSeenTime = 0;
int lastError = 0;

void setup() {
    Serial.begin(9600);

    display.clear();
    display.print("Obstacle Bot");
    display.gotoXY(0, 1);
    display.print("Press B");

    initLineSensors();
    buttonB.waitForButton();

    display.clear();
    display.print("Calibrating...");
    delay(500);

    calibrateLineSensors();

    display.clear();
    display.print("Ready!");
    display.gotoXY(0, 1);
    display.print("Press B");
    delay(500);
}


void loop() {
    switch (currentState) {

        case STOPPED: {
            motors.setSpeeds(0, 0);

            // calibration helper — read and print sensor values
            lineSensors.read(rawSensorValues);
            Serial.print("S0:"); Serial.print(rawSensorValues[0]);
            Serial.print(" S1:"); Serial.print(rawSensorValues[1]);
            Serial.print(" S2:"); Serial.print(rawSensorValues[2]);
            Serial.print(" S3:"); Serial.print(rawSensorValues[3]);
            Serial.print(" S4:"); Serial.println(rawSensorValues[4]);

            display.clear();
            display.print("STOPPED");
            display.gotoXY(0, 1);
            display.print("Press B");

            if (buttonB.getSingleDebouncedPress()) {
                currentState = FOLLOWING_LINE;
            }
            break;
        }

        case FOLLOWING_LINE: {
            // 1 — check obstacle every 4 iterations
            static unsigned int frameCount = 0;
            if (frameCount++ % 4 == 0) {
                if (obstacleDetected()) {
                    motors.setSpeeds(0, 0);
                    display.clear();
                    display.print("OBSTACLE!");
                    resetAvoidance();          
                    currentState = AVOIDING_OBSTACLE;
                    break;
                }
            }

            // 2 — gap detection
            if (isLineVisible()) {
                lastLineSeenTime = millis();
            } else if (millis() - lastLineSeenTime <= MAX_GAP_TIME) {
                // short gap — drive straight and wait
                motors.setSpeeds(BASE_SPEED, BASE_SPEED);
                break;
            } else {
                // long gap — coast 1500ms checking for line
                display.clear();
                display.print("Gap! Coasting");
                motors.setSpeeds(BASE_SPEED, BASE_SPEED);
                unsigned long coastStart = millis();
                while (millis() - coastStart < 1500) {
                    if (isLineVisible()) { lastLineSeenTime = millis(); break; }
                }
                if (isLineVisible()) break;

                // still no line — sweep left then right
                motors.setSpeeds(0, 0);
                display.clear();
                display.print("Searching...");

                unsigned long sweepStart = millis();
                motors.setSpeeds(-80, 80);
                while (millis() - sweepStart < 1000) {
                    if (isLineVisible()) { motors.setSpeeds(0, 0); lastError = 0; lastLineSeenTime = millis(); break; }
                    delay(10);
                }
                if (isLineVisible()) break;

                sweepStart = millis();
                motors.setSpeeds(80, -80);
                while (millis() - sweepStart < 2000) {
                    if (isLineVisible()) { motors.setSpeeds(0, 0); lastError = 0; lastLineSeenTime = millis(); break; }
                    delay(10);
                }
                if (isLineVisible()) break;

                motors.setSpeeds(0, 0);
                currentState = STOPPED;
                break;
            }

            // 3 — PD line following
            int position = readLinePosition();
            int error = position - LINE_CENTER;
            int correction = KP * error + KD * (error - lastError);
            lastError = error;

            int leftSpeed  = constrain(BASE_SPEED + correction, 0, MAX_SPEED);
            int rightSpeed = constrain(BASE_SPEED - correction + MOTOR_TRIM, 0, MAX_SPEED);
            motors.setSpeeds(leftSpeed, rightSpeed);

            if (buttonB.getSingleDebouncedPress()) {
                currentState = STOPPED;
            }
            break;
        }

        case AVOIDING_OBSTACLE: {
            if (stepAvoidance()) {
                display.clear();
                display.print("Back on line!");
                motors.setSpeeds(BASE_SPEED * 0.5, BASE_SPEED * 0.5);
                delay(300);
                motors.setSpeeds(0, 0);
                lastLineSeenTime = millis();
                lastError = 0;
                currentState = FOLLOWING_LINE;
            }
            break;
        }
    }
}