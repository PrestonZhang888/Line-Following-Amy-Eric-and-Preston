
#ifndef ROBOT_CONFIG_H
#define ROBOT_CONFIG_H
const float COUNTS_PER_ROTATION = 909.7;
const float WHEEL_DIAMETER_MM = 39.0;
const float WHEEL_CIRCUMFERENCE_MM = 3.14159 * WHEEL_DIAMETER_MM;
const float COUNTS_PER_CM = COUNTS_PER_ROTATION / (WHEEL_CIRCUMFERENCE_MM / 10.0);
const float WHEEL_BASE_MM = 85.0;
const float TURN_CIRCUMFERENCE_MM = 3.14159 * WHEEL_BASE_MM;
const float COUNTS_PER_DEGREE = (TURN_CIRCUMFERENCE_MM / 360.0) * 
                                (COUNTS_PER_ROTATION / WHEEL_CIRCUMFERENCE_MM);
const int DRIVE_SPEED = 150; 
const int TURN_SPEED = 140;

const int LINE_CENTER = 2000;
const int BASE_SPEED = 100;
const float KP = 0.05;
const float KD = 2.2;
const int MOTOR_TRIM = 8; // boost right motor to compensate for left motor weakness
const int MAX_SPEED = 250;
const unsigned long MAX_GAP_TIME = 900;  // ms off-line before gap recovery triggers
const unsigned long GAP_COAST_MS = 400;  // ms to keep driving forward through a gap
const int OBSTACLE_THRESHOLD  = 5;
const int AVOID_SPEED         = 150;
const int AVOID_TURN_MS    = 600;
const int AVOID_ALONGSIDE_MS = 800; // stage 2: drive alongside obstacle
const int AVOID_FORWARD_MS   = 1500;  // stage 4: drive past obstacle
const int RETURN_TURN_MS   = 550; 
const int AVOID_CLEAR_EXTRA_MS = 400; 


enum RobotState {
    FOLLOWING_LINE,
    AVOIDING_OBSTACLE,
    STOPPED
};
#endif 