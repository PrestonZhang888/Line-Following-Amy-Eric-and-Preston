#ifndef ROBOT_MOTION_H
#define ROBOT_MOTION_H

#include <Zumo32U4.h>
extern unsigned int rawSensorValues[5];
extern Zumo32U4Motors motors;
extern Zumo32U4Encoders encoders;

void driveDistance(float centimeters);
void turnDegrees(float degrees);
void turnLeft();
void turnRight();
void turnAround();

bool stepAvoidance();
void resetAvoidance();

#endif