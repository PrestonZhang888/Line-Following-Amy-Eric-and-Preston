#include "RobotSensors.h"
#include <Zumo32U4.h>
#include "RobotConfig.h"

Zumo32U4LineSensors lineSensors;
extern Zumo32U4Motors motors;
unsigned int sensorValues[5];
int lastPosition = LINE_CENTER;

void initLineSensors() {
    lineSensors.initFiveSensors();  // Initialize 5 sensors
}

void calibrateLineSensors() {
    for (int i = 0; i < 100; i++) {
        if (i < 50) {
            motors.setSpeeds(100, -100);  // Spin left
        } else {
            motors.setSpeeds(-100, 100);  // Spin right
        }
        lineSensors.calibrate();
    }
    motors.setSpeeds(0, 0);
}

int readLinePosition() {
    lastPosition = lineSensors.readLine(sensorValues);
    return lastPosition;
}

bool isLineVisible() {
    lineSensors.read(sensorValues);
    unsigned int sum = 0;
    for (int i = 0; i < 5; i++) {
        sum += sensorValues[i];
    }
    return sum > 0;
}

bool isGreen(int sensorValue) {
    return (sensorValue >= GREEN_LOW_THRESHOLD && 
            sensorValue <= GREEN_HIGH_THRESHOLD);
}

IntersectionType checkForIntersection() {
    unsigned int sensorValues[5];
    lineSensors.read(sensorValues);
    
    bool leftGreen = isGreen(sensorValues[0]);
    bool rightGreen = isGreen(sensorValues[4]);
    
    if (leftGreen && rightGreen) {
        return DEAD_END;
    } else if (leftGreen) {
        return TURN_LEFT;
    } else if (rightGreen) {
        return TURN_RIGHT;
    } else {
        return NO_INTERSECTION;
    }
}