#include <Zumo32U4.h>
#include "RobotConfig.h"
#include "RobotMotion.h"
#include "RobotSensors.h"

// ===== GLOBAL STATE =====
RobotState currentState = STOPPED;
IntersectionType pendingTurn = NO_INTERSECTION;

Zumo32U4OLED display;
Zumo32U4ButtonA buttonA;
Zumo32U4ButtonB buttonB;
Zumo32U4ButtonC buttonC;
Zumo32U4Buzzer buzzer;
extern Zumo32U4Motors motors;

float currentKp = KP;           // Tunable Kp value
bool isRunning = false;         // Running state
unsigned long gapStartTime = 0; // For gap handling

void showStatus() {
    display.clear();
    display.print(isRunning ? "RUNNING" : "STOPPED");
    display.gotoXY(0, 1);
    display.print(F("Kp: "));
    display.print(currentKp, 2);
    display.gotoXY(0, 3);
    display.print(F("A- B:Go C+"));
}

void followLine() {
    int position = readLinePosition();
    int error = position - LINE_CENTER;
    int correction = currentKp * error;
    
    int leftSpeed = BASE_SPEED + correction;
    int rightSpeed = BASE_SPEED - correction;
    
    leftSpeed = constrain(leftSpeed, -MAX_SPEED, MAX_SPEED);
    rightSpeed = constrain(rightSpeed, -MAX_SPEED, MAX_SPEED);
    
    motors.setSpeeds(leftSpeed, rightSpeed);
}

void handleGap() {
    // Continue straight when line is lost
    if (gapStartTime == 0) {
        gapStartTime = millis();
    }
    
    // Check for timeout
    if (millis() - gapStartTime > MAX_GAP_TIME) {
        motors.setSpeeds(0, 0);
        isRunning = false;
        display.clear();
        display.print(F("LINE LOST!"));
        return;
    }
    
    // Keep going straight
    motors.setSpeeds(BASE_SPEED, BASE_SPEED);
}

void setup() {
    Serial.begin(115200);
    delay(500);
    Serial.println(F("=== Lesson 9: Intersections & Dead Ends ==="));

    // ===== BATTERY CHECK =====
    int batteryVoltage = readBatteryMillivolts();
    int battWhole = batteryVoltage / 1000;
    int battDecimal = (batteryVoltage / 10) % 100;
    
    Serial.print(F("Battery: "));
    Serial.print(battWhole);
    Serial.print(F("."));
    if (battDecimal < 10) Serial.print(F("0"));
    Serial.print(battDecimal);
    Serial.print(F("V ("));
    Serial.print(batteryVoltage);
    Serial.println(F("mV)"));
    
    display.clear();
    display.setLayout11x4();
    display.gotoXY(0, 0);
    display.print(F("BATTERY"));
    display.gotoXY(0, 1);
    display.print(battWhole);
    display.print(F("."));
    if (battDecimal < 10) display.print(F("0"));
    display.print(battDecimal);
    display.print(F("V"));
    display.gotoXY(0, 2);
    display.print(F("Press btn"));
    display.gotoXY(0, 3);
    
    if (batteryVoltage >= BATTERY_GOOD) {
        display.print(F("GOOD"));
        ledGreen(1);
    } else if (batteryVoltage >= BATTERY_LOW) {
        display.print(F("LOW"));
        ledYellow(1);
        buzzer.playNote(NOTE_A(4), 200, 15);
    } else {
        display.print(F("CHARGE!"));
        ledRed(1);
        buzzer.playNote(NOTE_A(3), 500, 15);
    }
    
    while (!buttonA.getSingleDebouncedPress() &&
           !buttonB.getSingleDebouncedPress() &&
           !buttonC.getSingleDebouncedPress()) {
        delay(10);
    }
    ledGreen(0);
    ledYellow(0);
    ledRed(0);
    // ===== END BATTERY CHECK =====

    // Initialize and calibrate line sensors
    calibrateLineSensors();

    // Welcome screen
    display.clear();
    display.setLayout11x4();
    display.gotoXY(0, 0);
    display.print(F("LESSON 9"));
    display.gotoXY(0, 1);
    display.print(F("Intersect"));
    display.gotoXY(0, 2);
    display.print(F("Press B"));
    
    buttonB.waitForButton();
    
    // 3-2-1 countdown
    for (int i = 3; i > 0; i--) {
        display.clear();
        display.gotoXY(5, 1);
        display.print(i);
        buzzer.playNote(NOTE_A(4), 200, 15);
        delay(1000);
    }
    display.clear();
    display.print(F("GO!"));
    
    currentState = FOLLOWING_LINE;
}

void loop() {
    switch (currentState) {
        
        case FOLLOWING_LINE: {
            int position = readLinePosition();
            int error = position - LINE_CENTER;
            int correction = KP * error;
            
            int leftSpeed = BASE_SPEED + correction;
            int rightSpeed = BASE_SPEED - correction;
            
            leftSpeed = constrain(leftSpeed, 0, MAX_SPEED);
            rightSpeed = constrain(rightSpeed, 0, MAX_SPEED);
            
            Zumo32U4Motors::setSpeeds(leftSpeed, rightSpeed);
            
            IntersectionType intersection = checkForIntersection();
            if (intersection != NO_INTERSECTION) {
                pendingTurn = intersection;
                currentState = AT_INTERSECTION;
            }
            break;
        }
        
        case AT_INTERSECTION: {
            Zumo32U4Motors::setSpeeds(0, 0);
            
            Zumo32U4OLED display;
            display.clear();
            if (pendingTurn == TURN_LEFT) display.print(F("LEFT"));
            else if (pendingTurn == TURN_RIGHT) display.print(F("RIGHT"));
            else if (pendingTurn == DEAD_END) display.print(F("DEAD END"));
            
            delay(100);
            currentState = EXECUTING_TURN;
            break;
        }
        
        case EXECUTING_TURN: {
            if (pendingTurn == TURN_LEFT) turnLeft();
            else if (pendingTurn == TURN_RIGHT) turnRight();
            else if (pendingTurn == DEAD_END) turnAround();
            
            pendingTurn = NO_INTERSECTION;
            currentState = FOLLOWING_LINE;
            break;
        }
        
        case STOPPED: {
            Zumo32U4Motors::setSpeeds(0, 0);
            
            Zumo32U4ButtonB buttonB;
            if (buttonB.isPressed()) {
                delay(500);
                currentState = FOLLOWING_LINE;
            }
            break;
        }
    }
}
