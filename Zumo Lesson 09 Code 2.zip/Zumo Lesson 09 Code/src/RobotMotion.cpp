/* This file IMPLEMENTS the movement functions
declared in RobotMotion.h
=====================================================
*/

#include "RobotMotion.h"
#include "RobotConfig.h"
#include <Zumo32U4.h>

// ===== HARDWARE OBJECTS =====
// These are used internally by this file
Zumo32U4Motors motors;
Zumo32U4Encoders encoders;

// ===== FUNCTION IMPLEMENTATIONS =====

void driveDistance(float centimeters) {
    // Reset encoders to start counting from zero
    encoders.getCountsAndResetLeft();
    encoders.getCountsAndResetRight();
    
    // Calculate how many encoder counts we need
    int targetCounts = abs(centimeters) * COUNTS_PER_CM;
    
    // Set motor direction based on positive/negative distance
    int speed = (centimeters > 0) ? DRIVE_SPEED : -DRIVE_SPEED;
    
    // Start driving
    motors.setSpeeds(speed, speed);
    
    // Keep driving until we reach the target
    while (abs(encoders.getCountsLeft()) < targetCounts) {
        delay(10);  // Small delay to prevent hogging the CPU
    }
    
    // Stop!
    motors.setSpeeds(0, 0);
}

void turnDegrees(float degrees) {
    // Reset encoders
    encoders.getCountsAndResetLeft();
    encoders.getCountsAndResetRight();
    
    // Calculate target counts for the turn
    int targetCounts = abs(degrees) * COUNTS_PER_DEGREE;
    
    // Set wheel directions for turning
    // Positive degrees = turn right (left wheel forward, right wheel backward)
    int leftSpeed = (degrees > 0) ? TURN_SPEED : -TURN_SPEED;
    int rightSpeed = -leftSpeed;  // Opposite direction
    
    // Start turning
    motors.setSpeeds(leftSpeed, rightSpeed);
    
    // Keep turning until we reach the target
    while (abs(encoders.getCountsLeft()) < targetCounts) {
        delay(10);
    }
    
    // Stop!
    motors.setSpeeds(0, 0);
}

void turnLeft() {
    Zumo32U4Motors::setSpeeds(-TURN_SPEED, TURN_SPEED);
    delay(TURN_DURATION_90);
    Zumo32U4Motors::setSpeeds(0, 0);
}

void turnRight() {
    Zumo32U4Motors::setSpeeds(TURN_SPEED, -TURN_SPEED);
    delay(TURN_DURATION_90);
    Zumo32U4Motors::setSpeeds(0, 0);
}

void turnAround() {
    Zumo32U4Motors::setSpeeds(TURN_SPEED, -TURN_SPEED);
    delay(TURN_DURATION_180);
    Zumo32U4Motors::setSpeeds(0, 0);
}
