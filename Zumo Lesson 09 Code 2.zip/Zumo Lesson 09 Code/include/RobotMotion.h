/*
=====================================================
ROBOTMOTION.H - Movement Function Declarations
=====================================================

This file DECLARES the movement functions.
The actual code (implementation) is in RobotMotion.cpp
=====================================================
*/
#pragma once
#include "RobotConfig.h"

// ===== TURN FUNCTIONS =====
void turnLeft();
void turnRight();
void turnAround();
void driveDistance(float centimeters);
void turnDegrees(float degrees);