#pragma once
#include "RobotConfig.h"
#include <Zumo32U4.h>

extern Zumo32U4LineSensors lineSensors;


// Initialize the line sensor array
void initLineSensors();

// Calibrate sensors (robot spins to see black and white)
void calibrateLineSensors();

// Get line position (0-4000, 2000 = centered)
int readLinePosition();

// Check if line is currently visible
bool isLineVisible();

//===== GREEN DETECTION =====
bool isGreen(int sensorValue);
IntersectionType checkForIntersection();
