/*=====================================================

All robot-specific values in ONE place!
Edit this file to tune your robot's performance.
=====================================================
*/

#pragma once
// ===== PHYSICAL PROPERTIES =====
// These values define your robot's hardware

// Encoder counts per complete wheel rotation
// (12 counts/motor rotation × 75.81 gear ratio = 909.7)
const float COUNTS_PER_ROTATION = 909.7;

// Wheel diameter in millimeters (measure yours!)
const float WHEEL_DIAMETER_MM = 39.0;

// Wheel circumference = π × diameter
const float WHEEL_CIRCUMFERENCE_MM = 3.14159 * WHEEL_DIAMETER_MM;

// Encoder counts per centimeter of travel
const float COUNTS_PER_CM = COUNTS_PER_ROTATION / (WHEEL_CIRCUMFERENCE_MM / 10.0);


// ===== TURNING PROPERTIES =====
// Distance between wheel centers (for turn calculations)
const float WHEEL_BASE_MM = 85.0;

// Circumference of the turn circle
const float TURN_CIRCUMFERENCE_MM = 3.14159 * WHEEL_BASE_MM;

// Encoder counts per degree of rotation
const float COUNTS_PER_DEGREE = (TURN_CIRCUMFERENCE_MM / 360.0) * 
                                (COUNTS_PER_ROTATION / WHEEL_CIRCUMFERENCE_MM);

// ===== SPEED SETTINGS =====
// Adjust these to change robot behavior
const int DRIVE_SPEED = 150;  // Speed for straight driving (0-400)
const int TURN_SPEED = 150;   // Speed for turning (0-400)

// ===== BATTERY THRESHOLDS =====
const int BATTERY_GOOD = 4800;  // millivolts — fully charged
const int BATTERY_LOW  = 4200;  // millivolts — charge soon

// ===== LINE FOLLOWING CONSTANTS =====
const int LINE_CENTER = 2000;           // Setpoint (0-4000 range)
const int BASE_SPEED = 200;             // Forward speed when centered
const float KP = 0.6;                   // Proportional gain (tune this!)
const int MAX_SPEED = 300;              // Maximum motor speed
const int LINE_LOST_THRESHOLD = 200;    // Below this = no line detected
const unsigned long MAX_GAP_TIME = 500; // Max ms to cross a gap

// ===== INTERSECTION DETECTION CONSTANTS =====
const int GREEN_LOW_THRESHOLD = 80;
const int GREEN_HIGH_THRESHOLD = 200;

// ===== TURN CONSTANTS =====
const int TURN_DURATION_90 = 300;
const int TURN_DURATION_180 = 600;

// ===== INTERSECTION TYPES (enum) =====
enum IntersectionType {
    NO_INTERSECTION,
    TURN_LEFT,
    TURN_RIGHT,
    DEAD_END
};

// ===== ROBOT STATES (enum) =====
enum RobotState {
    FOLLOWING_LINE,
    AT_INTERSECTION,
    EXECUTING_TURN,
    STOPPED
};